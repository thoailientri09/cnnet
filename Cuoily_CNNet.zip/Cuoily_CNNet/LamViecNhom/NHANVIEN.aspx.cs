﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LamViecNhom
{
    public partial class quanlynhanvien : System.Web.UI.Page
    {
        string ConnectionString = ConfigurationManager.ConnectionStrings["cuoiki"].ConnectionString;
        SqlConnection conn;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                loadnv();
            }

        }
        // Hàm đưa dữ liệu lên gridview
        public void loadnv()
        {
            String sql = "Select UserName,TenNV,DiaChi,GioiTinh,SoDienThoai from NhanVien";
            conn = new SqlConnection(ConnectionString);
            SqlCommand com = new SqlCommand(sql, conn);
            conn.Open();
            SqlDataReader dr = com.ExecuteReader();
            GridView1.DataSource = dr;
            GridView1.DataBind();
            dr.Close();
            conn.Close();

        }
        // Thông báo
        public void Messagebox(string xMessage)
        {
            Response.Write("<script>alert('" + xMessage + "')</script>");
        }
        // Kiểm tra xem UserName đã tồn tại chưa
        public bool check()
        {
            conn = new SqlConnection(ConnectionString);
            conn.Open();
            string sqlcheck = "select COUNT(*) from NhanVien where UserName='" + txtuser.Text + "'";
            SqlCommand com = new SqlCommand(sqlcheck, conn);
            int sl = (int)com.ExecuteScalar();
            if (sl >= 1)
                return true;
            return false;
           
        }
        // Thêm nhân viên
        protected void btnluu_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection(ConnectionString);
            conn.Open();
            if (txtmadmin.Text == "123")
            {
                //kiểm tra trùng 
                if (check() == false)
                {
                    string sqlthem = "insert into NhanVien values(@UserName,@PassWord,@TenNV,@DiaChi,@GioiTinh,@SoDienThoai)";
                    SqlCommand com = new SqlCommand(sqlthem, conn);
                    com.Parameters.AddWithValue("UserName", txtuser.Text);
                    com.Parameters.AddWithValue("PassWord", txtpass.Text);
                    com.Parameters.AddWithValue("TenNV", txtten.Text);
                    com.Parameters.AddWithValue("DiaChi", txtdiachi.Text);
                    com.Parameters.AddWithValue("GioiTinh", DropDownList1.Text);
                    com.Parameters.AddWithValue("SoDienThoai", txtsdt.Text);

                    com.ExecuteNonQuery();
                    Messagebox("Bạn có muốn đăng ký với UserName: " + txtuser.Text + " Không?");
                    Label7.Text = "Đăng ký thành công";
                }
                else
                    Label7.Text = "Tài khoản đã tồn tại";
            }
            else
                Label7.Text = "Vui lòng nhập đúng mã Admin để được thao tác!";
        }
        public void xoa()
        {
            if (txtmadmin.Text == "123")
            {
                conn = new SqlConnection(ConnectionString);
                conn.Open();
                string sqlXoa = "DELETE FROM NhanVien Where UserName=@UserName";
                SqlCommand com = new SqlCommand(sqlXoa, conn);
                com.Parameters.AddWithValue("UserName", txtuser.Text);
                com.ExecuteNonQuery();
                Messagebox("Bạn có muốn xóa UserName:" + txtuser.Text + "Không?");
                Label7.Text = "Xóa thành công";
                if (Label7.Text.Equals("Xóa thành công"))
                {
                    Response.Redirect("NHANVIEN.aspx");
                }
                Label7.Text = "Xóa thành công";
            }
            else
                Label7.Text = "Vui lòng nhập đúng mã Admin để được thao tác!";
        }


        // Tìm kiếm nhân viên
        protected void btntim_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection(ConnectionString);
            conn.Open();
            string sqltim = "select UserName,TenNV,DiaChi,GioiTinh,SoDienThoai from NhanVien where UserName='" + txtuser.Text + "'";
            SqlCommand com = new SqlCommand(sqltim, conn);
            SqlDataReader dr = com.ExecuteReader();
            GridView1.DataSource = dr;
            GridView1.DataBind();
            dr.Close();
            conn.Close();
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtuser.Text = HttpUtility.HtmlDecode((string)GridView1.SelectedRow.Cells[2].Text);
            //txtpass.Text = HttpUtility.HtmlDecode((string)GridView1.SelectedRow.Cells[3].Text);
            txtten.Text = HttpUtility.HtmlDecode((string)GridView1.SelectedRow.Cells[3].Text);
            txtdiachi.Text = HttpUtility.HtmlDecode((string)GridView1.SelectedRow.Cells[4].Text);
            DropDownList1.Text = HttpUtility.HtmlDecode((string)GridView1.SelectedRow.Cells[5].Text);
            txtsdt.Text = HttpUtility.HtmlDecode((string)GridView1.SelectedRow.Cells[6].Text);
        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            xoa();
        }

        protected void btnsua_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection(ConnectionString);
            conn.Open();
            if (txtmadmin.Text == "123")
            {
                if (txtuser.Text != "")
                {
                    string sqlsua = "UPDATE NhanVien SET UserName=@UserName,PassWord=@PassWord ,TenNV=@TenNV,DiaChi=@DiaChi,GioiTinh=@GioiTinh,SoDienThoai=@SoDienThoai where UserName=@UserName";
                    SqlCommand com = new SqlCommand(sqlsua, conn);
                    com.Parameters.AddWithValue("UserName", txtuser.Text);
                    com.Parameters.AddWithValue("PassWord", txtpass.Text);
                    com.Parameters.AddWithValue("TenNV", txtten.Text);
                    com.Parameters.AddWithValue("DiaChi", txtdiachi.Text);
                    com.Parameters.AddWithValue("GioiTinh", DropDownList1.Text);
                    com.Parameters.AddWithValue("SoDienThoai", txtsdt.Text);
                    com.ExecuteNonQuery();
                    Label7.Text = "Cập nhập thành công";
                    if (Label7.Text.Equals("Cập nhập thành công"))
                    {
                        Response.Redirect("NHANVIEN.aspx");
                    }
                }
                else
                {
                    Label7.Text = "Chưa nhập ID";
                }

            }
            else
                Label7.Text = "Vui lòng nhập đúng mã Admin để được thao tác!";

        }
    }
}