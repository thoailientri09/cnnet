﻿-- lần 2
USE master
GO
IF EXISTS(SELECT name FROM sysdatabases WHERE name ='lamviecnhom')
DROP DATABASE lamviecnhom
go

--lần đầu đầu 1
CREATE DATABASE lamviecnhom
GO
USE lamviecnhom
GO




CREATE TABLE  dbo.KhachHang (
	 MaKH 			char (20) not null primary key,
	 TenKH 			nvarchar (50) not null,
	 DiaChi 		nvarchar (max) null,
	 SoDienThoai 	char (10) null check(SoDienThoai like '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),

	)

insert into KhachHang
	values  ('KH001',N'Thu Hiền'	,N' Đà Nẵng','0976888345'),
			('KH002',N'Thị Mai'		,N' Đà Nẵng','0976888333'),
			('KH003',N'Hoang Anh'	,N' Đà Nẵng','0976888444'),
			('KH004',N'Thiên Thoại'	,N' Bình Định','0976888555'),
			('KH005',N'Võ Lập'		,N' Bình Định','0976888666');


CREATE TABLE  dbo.NhanVien (
	 UserName 	 char (20) not null primary key,
	 PassWord	 char (30) not null,
	 TenNV 		 nvarchar (50) not null,	 
	 DiaChi		 nvarchar (max) null,
	 GioiTinh 	 nvarchar(3) not null ,
	 SoDienThoai char (10) null check(SoDienThoai like '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
)
insert into NhanVien
	values  ('NV001','NV001',N'Văn Thắng',N'Bình Định','Nam','0976888866'),
			('NV002','NV002',N'Văn Thắng',N'Quảng Nam','Nam','0976888444'),
			('NV003','NV002',N'Trọng Nhân',N'Quảng Nam','Nam','0976777345'),
			('NV004','NV002',N'Cẩm Vân',N'Phú Yên'	,'Nữ','0976777888'),
			('NV005','NV002',N'Quỳnh Tiên'	,N'Phú Yên'	,'Nữ','0976777999');
		
	CREATE TABLE   dbo.SanPham  (
	 MaSP		char (20)not null primary key,
	 TenSP		char (40)  not null   ,
	 MaLoai		char (40)  not null   ,
	 SoLuong	char (40)  not null   ,
	 DonGia		Decimal(18,3)   NULL,
	 Picture	TEXT	NULL,

)		

CREATE TABLE   dbo.ChiTietSanPham  (
	 MaSP			char (20)not null foreign key references SanPham (MaSP) ,
	 HeDieuHanh		char (40)  not null   ,
	 ManHinh		char (40)  not null   ,
	 Camera			char (40)  not null   ,
	 CPU			char (40)  not null   ,
	 RAM			char (40)  not null   ,
	 DungLuongPin	char (40)  not null   ,
)

CREATE TABLE   dbo.HoaDon  (
	 SoHoaDon		char (20)not null primary key,
	 MaKH	char (20)  not null  foreign key references KhachHang(MaKH) ,
	 MaSP	char (20)  not null  foreign key references SanPham (MaSP) ,
	 NgayBan datetime   not null,
	 SoLuongBan	int		 NULL,
	 DonGia	Decimal(18,3)   NULL,
	 TienThanhToan	Decimal(18,3)   NULL,
	 UserName char (20) not null foreign key references NhanVien (UserName ) ,

)



